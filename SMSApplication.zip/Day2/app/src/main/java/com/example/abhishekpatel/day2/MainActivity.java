package com.example.abhishekpatel.day2;

import android.Manifest;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {

    EditText et1,et2;
    Button btn1;
    TextView ed1;
    //Dexter Variable
    PermissionListener smsPermissionListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = (EditText)findViewById(R.id.txtNumber);
        et2 = (EditText)findViewById(R.id.txtMessage);
        btn1 = (Button)findViewById(R.id.btnSMS);
        ed1 = (TextView)findViewById(R.id.tv1);

        createPermissionListener();
    }

    private void createPermissionListener() {
        // A function to dela with permission


        //1. Check if permission Listener variable is set up
        if (smsPermissionListener == null){

            smsPermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                    // what should you do if person allows

                    Log.d("Abhishek","SMS sent");

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("4377782213",null,"hey Whatsup ?", null, null);


                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                    // what should if the person denied

                    Log.d("Abhishek","Person Picked Denied, I can't send the message");
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    //what if permission is already set to denied
                    token.continuePermissionRequest();

                }
            };
        }
    }

    public  void smsButtonPressed(View v){

        Log.d("Abhishek","Button Pressed");



        //ASK for permission (Show for the pop up)
        //->dexter is automatically going to run the nonsense in the
        //createPermissionListener()

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.SEND_SMS)
                .withListener(smsPermissionListener)
                .check();





//        //Write the code to send a sms
//        SmsManager smsManager = SmsManager.getDefault();
//
//
//        smsManager.sendTextMessage("6476789634",null,"hey Whatsup ?", null, null);
//
//
//        Log.d("Abhishek","Message Sent");
//

    }
}
